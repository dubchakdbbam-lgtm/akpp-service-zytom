export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const order = req.body;
  // TODO: Save to DB / Google Sheets
  console.log('New order:', order);
  return res.status(200).json({ ok: true, orderId: Date.now() });
}
