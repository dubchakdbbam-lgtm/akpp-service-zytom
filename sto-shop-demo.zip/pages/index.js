import { useState } from 'react'
import { products as sampleProducts } from '../data/products'

export default function Home() {
  const [products] = useState(sampleProducts)
  const [cart, setCart] = useState([])
  const [cartOpen, setCartOpen] = useState(false)
  const [appointment, setAppointment] = useState({ name: '', phone: '', car: '', date: '' })

  function addToCart(product) {
    setCart(prev => {
      const found = prev.find(p => p.id === product.id)
      if (found) return prev.map(p => p.id === product.id ? { ...p, qty: p.qty + 1 } : p)
      return [...prev, { ...product, qty: 1 }]
    })
    setCartOpen(true)
  }

  function changeQty(id, delta) {
    setCart(prev => prev.map(p => p.id === id ? { ...p, qty: Math.max(1, p.qty + delta) } : p).filter(p => p.qty > 0))
  }

  function cartTotal() { return cart.reduce((s,p) => s + p.price * p.qty, 0) }

  async function checkout() {
    const payload = { items: cart, total: cartTotal(), createdAt: new Date().toISOString() }
    const res = await fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    const data = await res.json()
    if (data.ok) {
      alert('Замовлення прийнято. id: ' + data.orderId)
      setCart([])
      setCartOpen(false)
    } else alert('Помилка оформлення')
  }

  function submitAppointment(e) {
    e.preventDefault();
    alert(`Запис: ${appointment.name}, ${appointment.phone}, ${appointment.car}, ${appointment.date}`)
    setAppointment({ name: '', phone: '', car: '', date: '' })
  }

  return (
    <div>
      <header className="bg-neutral-900 text-white">
        <div className="max-w-6xl mx-auto px-4 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">АвтоСТО "Ваш Автосервіс"</h1>
            <p className="text-sm text-neutral-300">Ремонт • Діагностика • Магазин</p>
          </div>
          <div className="flex items-center gap-4">
            <a href="#contact" className="hidden sm:inline-block bg-yellow-400 text-black px-3 py-2 rounded-lg">Записатися</a>
            <button onClick={() => setCartOpen(true)} className="border border-neutral-700 px-3 py-2 rounded-lg">Кошик ({cart.reduce((s,p)=>s+p.qty,0)})</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-12">
        <section className="grid md:grid-cols-2 gap-8 items-center mb-12">
          <div>
            <h2 className="text-3xl font-extrabold mb-4">Професійне СТО та магазин запчастин</h2>
            <p className="text-neutral-600 mb-6">Швидко та надійно. Оригінальні запчастини в наявності.</p>
            <div className="flex gap-4"><a href="#services" className="px-5 py-3 bg-neutral-900 text-white rounded-lg">Послуги</a><a href="#shop" className="px-5 py-3 border rounded-lg">Магазин</a></div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-xl font-semibold mb-3">Швидкий запис</h3>
            <form onSubmit={submitAppointment} className="space-y-3">
              <input required value={appointment.name} onChange={e=>setAppointment({...appointment,name:e.target.value})} placeholder="Ім'я" className="w-full border rounded px-3 py-2" />
              <input required value={appointment.phone} onChange={e=>setAppointment({...appointment,phone:e.target.value})} placeholder="Телефон" className="w-full border rounded px-3 py-2" />
              <input value={appointment.car} onChange={e=>setAppointment({...appointment,car:e.target.value})} placeholder="Марка/модель" className="w-full border rounded px-3 py-2" />
              <input type="date" value={appointment.date} onChange={e=>setAppointment({...appointment,date:e.target.value})} className="w-full border rounded px-3 py-2" />
              <button className="w-full bg-yellow-400 text-black px-4 py-2 rounded">Записатися</button>
            </form>
          </div>
        </section>

        <section id="services" className="mb-12">
          <h3 className="text-2xl font-bold mb-4">Послуги</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow"> <h4 className="font-semibold">Діагностика</h4><p className="text-neutral-600">Комп'ютерна перевірка.</p></div>
            <div className="bg-white p-6 rounded-lg shadow"> <h4 className="font-semibold">Ремонт ДВС</h4><p className="text-neutral-600">Професійний ремонт двигуна.</p></div>
            <div className="bg-white p-6 rounded-lg shadow"> <h4 className="font-semibold">Трансмісія</h4><p className="text-neutral-600">Ремонт АКПП/DSG.</p></div>
          </div>
        </section>

        <section id="shop" className="mb-12">
          <div className="flex items-center justify-between mb-4"><h3 className="text-2xl font-bold">Магазин автозапчастин</h3><div className="text-sm text-neutral-500">Самовивіз або доставка</div></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map(p => (
              <div key={p.id} className="bg-white p-5 rounded-lg shadow flex flex-col">
                <div className="h-36 bg-neutral-100 rounded-md mb-4 flex items-center justify-center">Фото</div>
                <h4 className="font-semibold">{p.title}</h4>
                <p className="text-sm text-neutral-500 mb-3">{p.desc}</p>
                <div className="mt-auto flex items-center justify-between"><div className="font-bold">{p.price.toLocaleString()} ₴</div><button onClick={()=>addToCart(p)} className="px-3 py-2 bg-yellow-400 rounded text-black font-semibold">Додати</button></div>
              </div>
            ))}
          </div>
        </section>

        <section id="contact">
          <h3 className="text-2xl font-bold mb-4">Контакти</h3>
          <div className="bg-white p-6 rounded-lg shadow">
            <p><strong>Адреса:</strong> м. Ваше місто, вул. Прикладна 10</p>
            <p><strong>Телефон:</strong> +38 (068) 123-45-67</p>
            <p><strong>Пошта:</strong> info@vashauto.com</p>
          </div>
        </section>
      </main>

      <footer className="bg-neutral-900 text-white py-6 mt-12"><div className="max-w-6xl mx-auto px-4">© {new Date().getFullYear()} АвтоСТО "Ваш Автосервіс"</div></footer>

      {cartOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1" onClick={()=>setCartOpen(false)} />
          <div className="w-96 bg-white p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4"><h4 className="text-lg font-semibold">Кошик</h4><button onClick={()=>setCartOpen(false)} className="text-neutral-500">Закрити</button></div>
            <div className="space-y-4">
              {cart.length===0 && <div className="text-neutral-500">Кошик порожній</div>}
              {cart.map(item=> (
                <div key={item.id} className="flex items-center justify-between">
                  <div><div className="font-medium">{item.title}</div><div className="text-sm text-neutral-500">{item.sku} • {item.qty} × {item.price.toLocaleString()} ₴</div></div>
                  <div className="flex items-center gap-2"><button onClick={()=>changeQty(item.id,-1)} className="px-2 py-1 border rounded">-</button><button onClick={()=>changeQty(item.id,1)} className="px-2 py-1 border rounded">+</button><button onClick={()=>setCart(prev=>prev.filter(p=>p.id!==item.id))} className="px-2 py-1 text-red-500">Видалити</button></div>
                </div>
              ))}
            </div>
            <div className="mt-6 border-t pt-4"><div className="flex items-center justify-between mb-4"><div className="text-neutral-500">Разом</div><div className="font-bold">{cartTotal().toLocaleString()} ₴</div></div><button onClick={checkout} className="w-full bg-yellow-400 text-black px-4 py-2 rounded font-semibold">Оформити замовлення</button></div>
          </div>
        </div>
      )}
    </div>
  )
