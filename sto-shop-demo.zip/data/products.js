export const products = [
  { id: 1, title: "Масляний фільтр Bosch", price: 249, sku: "BF-1001", desc: "Для більшості легкових автомобілів" },
  { id: 2, title: "Моторна олива 5W-30 4л", price: 1199, sku: "OL-5W30-4L", desc: "Синтетична, API SN" },
  { id: 3, title: "Гальмівні колодки передні", price: 799, sku: "BK-FR-203", desc: "Брендові колодки з індикатором зносу" }
];
