# Sto Shop — Demo Next.js + Tailwind project

## How to run locally

1. Extract the ZIP.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Open http://localhost:3000

## Notes
- Replace `/public/logo.png` with your logo.
- The API endpoint `/pages/api/orders.js` only logs orders; connect a DB or Google Sheets for persistence.
- For production, configure environment variables and payment gateway securely.
